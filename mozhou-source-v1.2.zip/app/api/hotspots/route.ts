import type { Hotspot } from "../../lib/product-types";

const BAIDU_HOT_URL = "https://top.baidu.com/board?platform=pc&tab=realtime";
const CHINA_RSS_URL = "https://www.china.org.cn/rss/1185842.xml";

function cleanText(value: string) {
  return value
    .replace(/^<!\[CDATA\[|\]\]>$/g, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function walkHotData(value: unknown, found: Array<Record<string, unknown>>) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((item) => walkHotData(item, found));
    return;
  }
  const record = value as Record<string, unknown>;
  if (typeof record.word === "string" && (record.hotScore || record.desc || record.url)) found.push(record);
  Object.values(record).forEach((item) => walkHotData(item, found));
}

function parseBaidu(html: string): Hotspot[] {
  const records: Array<Record<string, unknown>> = [];
  const dataMatch = html.match(/<!--s-data:([\s\S]*?)-->/);
  if (dataMatch) {
    try {
      walkHotData(JSON.parse(dataMatch[1]), records);
    } catch {
      // Fall through to the page-source pattern below when Baidu changes its wrapper.
    }
  }

  if (!records.length) {
    const pattern = /\{"word":"((?:\\.|[^"\\])+)"[\s\S]{0,900}?"desc":"((?:\\.|[^"\\])*)"[\s\S]{0,600}?"hotScore":"?([0-9]+)"?/g;
    for (const match of html.matchAll(pattern)) {
      const decode = (raw: string) => {
        try {
          return JSON.parse(`"${raw}"`) as string;
        } catch {
          return raw;
        }
      };
      records.push({ word: decode(match[1]), desc: decode(match[2]), hotScore: match[3] });
    }
  }

  const seen = new Set<string>();
  return records
    .map((record) => {
      const title = cleanText(String(record.word ?? ""));
      const rawUrl = typeof record.url === "string" ? record.url : "";
      return {
        title,
        summary: cleanText(String(record.desc ?? "")).slice(0, 120),
        heat: record.hotScore ? `${record.hotScore} 热度` : undefined,
        url: rawUrl.startsWith("http") ? rawUrl : `https://www.baidu.com/s?wd=${encodeURIComponent(title)}`,
      };
    })
    .filter((item) => item.title && !seen.has(item.title) && seen.add(item.title))
    .slice(0, 12)
    .map((item, index) => ({ ...item, id: `baidu-${index + 1}`, rank: index + 1, source: "百度热搜" }));
}

function parseRss(xml: string): Hotspot[] {
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)]
    .map((match, index) => {
      const item = match[1];
      const field = (name: string) => cleanText(item.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`, "i"))?.[1] ?? "");
      const title = field("title");
      return {
        id: `china-${index + 1}`,
        rank: index + 1,
        title,
        summary: field("description").slice(0, 120),
        source: "中国网要闻",
        url: field("link") || "https://www.china.org.cn/",
      } satisfies Hotspot;
    })
    .filter((item) => item.title)
    .slice(0, 12);
}

async function fetchText(url: string) {
  const response = await fetch(url, {
    headers: {
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "user-agent": "Mozilla/5.0 (compatible; MozhouHotspotReader/1.0; +https://github.com/Yuhe94/mozhou-wechat-ai)",
    },
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`热点来源返回 ${response.status}`);
  return response.text();
}

export async function GET() {
  let lastError = "热点来源暂不可用";
  try {
    const hotspots = parseBaidu(await fetchText(BAIDU_HOT_URL));
    if (hotspots.length) {
      return Response.json(
        { hotspots, fetchedAt: new Date().toISOString(), source: "百度热搜" },
        { headers: { "cache-control": "public, s-maxage=300, stale-while-revalidate=600" } },
      );
    }
  } catch (error) {
    lastError = error instanceof Error ? error.message : lastError;
  }

  try {
    const hotspots = parseRss(await fetchText(CHINA_RSS_URL));
    if (hotspots.length) {
      return Response.json(
        { hotspots, fetchedAt: new Date().toISOString(), source: "中国网要闻" },
        { headers: { "cache-control": "public, s-maxage=300, stale-while-revalidate=600" } },
      );
    }
  } catch (error) {
    lastError = error instanceof Error ? error.message : lastError;
  }

  return Response.json({ error: `暂时无法获取社会热点：${lastError}` }, { status: 502 });
}
