import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(
    new Request(`http://localhost${pathname}`, { headers: { accept: "text/html" } }),
    {
      ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) },
    },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the Mozhou writing workspace", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  const html = await response.text();
  assert.match(html, /<title>墨舟｜微信公众号 AI 创作工作台<\/title>/i);
  assert.match(html, /微信公众号 AI 创作工作台/);
  assert.match(html, /创作简报/);
  assert.match(html, /参考改写/);
  assert.match(html, /社会热点/);
  assert.match(html, /400–600 字/);
  assert.match(html, /生成选题角度/);
  assert.match(html, /手机预览/);
  assert.doesNotMatch(html, /Your site is taking shape|codex-preview|react-loading-skeleton/);
});

test("ships the required creation, rewriting, hotspot, storage, and export surfaces", async () => {
  const root = new URL("../", import.meta.url);
  const [workspace, generator, hotspots, packager, productTypes, schema, hosting] = await Promise.all([
    readFile(new URL("app/workspace.tsx", root), "utf8"),
    readFile(new URL("app/api/generate/route.ts", root), "utf8"),
    readFile(new URL("app/api/hotspots/route.ts", root), "utf8"),
    readFile(new URL("app/lib/publish-package.client.ts", root), "utf8"),
    readFile(new URL("app/lib/product-types.ts", root), "utf8"),
    readFile(new URL("db/schema.ts", root), "utf8"),
    readFile(new URL(".openai/hosting.json", root), "utf8"),
  ]);

  assert.match(workspace, /generateTopics/);
  assert.match(workspace, /generateOutline/);
  assert.match(workspace, /generateDraft/);
  assert.match(workspace, /generateImages/);
  assert.match(workspace, /chooseHotspot/);
  assert.match(workspace, /exportPublicationPackage/);
  assert.match(workspace, /referenceArticle/);
  assert.match(generator, /client\.responses\.create/);
  assert.match(generator, /client\.images\.generate/);
  assert.match(generator, /参考原文改写/);
  assert.match(hotspots, /weibo\.com\/ajax\/side\/hotSearch/);
  assert.match(hotspots, /s\.weibo\.com\/top\/summary/);
  assert.match(hotspots, /toutiao\.com\/hot-event\/hot-board/);
  assert.match(hotspots, /Promise\.allSettled/);
  assert.match(productTypes, /CreationMode/);
  assert.match(packager, /IMG-01/);
  assert.match(packager, /zipSync/);
  assert.match(packager, /来源与版权清单/);
  assert.match(schema, /articles/);
  assert.match(schema, /assets/);
  const hostingConfig = JSON.parse(hosting);
  assert.equal(hostingConfig.d1, "DB");
  assert.equal(hostingConfig.r2, "UPLOADS");
  assert.match(hostingConfig.project_id, /^appgprj_/);
  await access(new URL("drizzle/0000_minor_firelord.sql", root));
  await assert.rejects(access(new URL("app/_sites-preview/SkeletonPreview.tsx", root)));
});
